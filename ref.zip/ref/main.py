import asyncio
import logging
import re
import time
import os
import sys

logging.basicConfig(level=logging.ERROR)

from telethon import TelegramClient, events
from telethon.tl.functions.channels import JoinChannelRequest
from telethon.tl.functions.messages import GetBotCallbackAnswerRequest
from datetime import datetime
from colorama import Fore, init as color_ama
color_ama(autoreset=True)

os.system('cls' if os.name=='nt' else 'clear')
# Get your own values from my.telegram.org
api_id = 800812
api_hash = 'db55ad67a98df35667ca788b97f771f5'
        # MASUKAM NAMA BOT TELEGRAM NYA DI SINI #
#===========================================================================#
#Nama_Bot = '@relictum_pro_chat'
#Nama_Grp = '@BuzzinBot'
#==============================================================================#
def print_msg_time(message):
	print('[' + Fore.CYAN + f'{datetime.now().strftime("%H:%M:%S")}' + Fore.RESET + f'] {message}')
async def main():
	print('')
        # Check if phone number is not specified
	if len(sys.argv) < 2:
		print('Usage: python start.py phone_number')
		print('-> Input number in international format (example: +639162995600)\n')
		e = input('Press any key to exit...')
		exit(1)
	phone_number = sys.argv[1]
	if not os.path.exists("session"):
		os.mkdir("session")
        # Connect to client
	client = TelegramClient('session/' + phone_number, api_id, api_hash)
	await client.start(phone_number)
	me = await client.get_me()
	print(f'               Nama Telegram Kamu: {me.first_name}({me.username})\n')
        # MASUKAN KODE REFF DI SINI AMBIL BELAKANG NYA SAJA #
#=============================================================================#
	await client(JoinChannelRequest('@relictum_pro_chat'))
#	await client(JoinChannelRequest('@EIDBONUSPAY'))
#	await client(JoinChannelRequest('@ETHBONUSUPDATE'))
#	await client(JoinChannelRequest('@NazadaxAnn'))
#	await client.send_message(Nama_Bot,'/start 748035640')
	#await client.send_message(Nama_Grp,'/start ecc031bd9f')
#============================================================================#
#	time.sleep(1)
	return
	await client.run_until_disconnected(2)
asyncio.get_event_loop().run_until_complete(main())
