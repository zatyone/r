want to make a bot click for Telegram. The problem is I'm confused about how I clicked it using my code, I tried it but it still failed and the bot didn't click, what data should be posted so that the bot clicks on the telegram bot. I need your help. This is my source code :

from telethon import TelegramClient, events, sync
from telethon.tl.functions.messages import GetHistoryRequest, GetBotCallbackAnswerRequest

api_id = 974119
api_hash = 'a483ea002564cdaa0499a08126abe4a3'
client = TelegramClient('session', api_id, api_hash)
client.start()
channel_username = '@ShikarbitBot'
channel_entity = client.get_entity(channel_username)
posts = client(GetHistoryRequest(
    peer=channel_entity,
    limit=1,
    offset_date=None,
    offset_id=0,
    max_id=0,
    min_id=0,
    add_offset=0,
    hash=0))
messageId = posts.messages[0].id

client(GetBotCallbackAnswerRequest(
    channel_username,
    messageId,
    data=posts.messages[0].reply_markup.rows[0].buttons[0]))

client.disconnect()
